(function () {
  'use strict';
  var main = document.getElementById('main');
  var toastRegion = document.getElementById('toast-region');
  var config = { categories: [], total: 0, settings: {} };
  var currentPath = '';
  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.getElementById('year').textContent = new Date().getFullYear();

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char];
    });
  }
  function num(value) {
    return new Intl.NumberFormat('en').format(Number(value) || 0);
  }
  function reviews(value) {
    value = Number(value) || 0;
    if (value >= 1000000) return (value / 1000000).toFixed(value % 1000000 < 100000 ? 0 : 1).replace(/\.0$/, '') + 'm reviews';
    if (value >= 1000) return (value / 1000).toFixed(value % 1000 < 100 ? 0 : 1).replace(/\.0$/, '') + 'k reviews';
    return num(value) + ' reviews';
  }
  function iconMarkup(app, extraClass) {
    var artNames = ['red', 'coral', 'sunset', 'violet', 'aqua', 'gold', 'meadow', 'ember'];
    var art = artNames.indexOf(app.icon_art) >= 0 ? app.icon_art : 'red';
    var mark = esc(app.icon_mark || (app.title || 'B').slice(0, 1));
    return '<div class="app-icon art-' + art + (extraClass ? ' ' + extraClass : '') + '" aria-hidden="true"><span>' + mark + '</span>' +
      (app.icon_path ? '<img src="/media/' + esc(app.icon_path) + '" alt="">' : '') + '</div>';
  }
  function ratingMarkup(app) {
    if (app.rating == null) return '<span class="card-rating">New listing</span>';
    return '<span class="card-rating"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="m8 1.5 2 4.1 4.5.7-3.3 3.2.8 4.5L8 11.9l-4 2.1.8-4.5-3.3-3.2L6 5.6z"/></svg>' + Number(app.rating).toFixed(1) + '</span>';
  }
  function card(app) {
    return '<a class="app-card" href="/app/' + esc(app.slug) + '" aria-label="View ' + esc(app.title) + '">' +
      '<div class="card-topline"><span class="card-tag">' + esc(app.featured ? 'Editor pick' : app.kind === 'app' ? 'App' : 'Game') + '</span>' + ratingMarkup(app) + '</div>' +
      '<div class="card-main">' + iconMarkup(app) + '<div class="card-name-wrap"><h3 class="card-name">' + esc(app.title) + '</h3><div class="card-category">' + esc(app.category || 'Uncategorised') + '</div></div></div>' +
      '<div class="card-bottom"><span class="card-size"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.5" y="2" width="11" height="12" rx="2"/><path d="M5.5 5h5m-5 3h5m-5 3h2"/></svg>' + esc(app.file_size || 'Details inside') + '</span><span class="card-arrow"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9m-4-4 4 4-4 4"/></svg></span></div></a>';
  }
  function cardGrid(items) {
    return items.length ? '<div class="card-grid">' + items.map(card).join('') + '</div>' : emptyState('No listings here yet', 'New discoveries will show up here as soon as they are added.', 'Browse all games', '/games');
  }
  function emptyState(title, body, action, href) {
    return '<div class="empty-state"><div class="empty-icon" aria-hidden="true">✦</div><h3>' + esc(title) + '</h3><p>' + esc(body) + '</p>' +
      (action ? '<a class="button button-secondary" href="' + esc(href || '/') + '">' + esc(action) + '</a>' : '') + '</div>';
  }
  function sectionHead(kicker, title, subtitle, href, linkText) {
    return '<div class="section-head"><div><div class="section-kicker">' + esc(kicker) + '</div><h2 class="section-title">' + esc(title) + '</h2>' +
      (subtitle ? '<p class="section-subtitle">' + esc(subtitle) + '</p>' : '') + '</div>' +
      (href ? '<a class="text-link" href="' + esc(href) + '">' + esc(linkText || 'View all') + '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9m-4-4 4 4-4 4"/></svg></a>' : '') + '</div>';
  }
  function searchIcon() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></svg>';
  }
  function heroArt(app) {
    app = app || { title: 'A new world', category: 'Featured', icon_mark: '✦', icon_art: 'coral' };
    return '<div class="hero-art" aria-hidden="true"><div class="orbit"></div><span class="sparkle s-one">✳</span><span class="sparkle s-two">✦</span>' +
      '<div class="hero-showcase"><div class="showcase-top"><span class="showcase-label">Betvixo spotlight</span><span class="showcase-status"><i></i> Picked for you</span></div>' +
      '<div class="showcase-cover"><span class="showcase-sun"></span><span class="showcase-mountain"></span></div>' +
      '<div class="showcase-info">' + iconMarkup(app) + '<span><strong>' + esc(app.title) + '</strong><small>' + esc(app.category || 'Featured game') + ' · ' + (app.rating == null ? 'New discovery' : Number(app.rating).toFixed(1) + ' rated') + '</small></span></div></div>' +
      '<div class="float-chip chip-one"><i>✧</i><span>Find your next favorite</span></div><div class="float-chip chip-two"><i>↗</i><span>Official download links</span></div></div>';
  }
  function heroHeading(text) {
    var lines = String(text || 'Find your next\nplay.').split('\n');
    if (lines.length > 1) return esc(lines[0]) + '<br><span class="accent">' + esc(lines.slice(1).join(' ')) + '</span>';
    var words = lines[0].split(' ');
    if (words.length > 2) return esc(words.slice(0, -1).join(' ')) + ' <span class="accent">' + esc(words[words.length - 1]) + '</span>';
    return '<span class="accent">' + esc(lines[0]) + '</span>';
  }
  async function api(url, options) {
    var response = await fetch(url, Object.assign({ headers: { Accept: 'application/json' } }, options || {}));
    var body = {};
    try { body = await response.json(); } catch (_) {}
    if (!response.ok) throw new Error(body.error || 'Something went wrong. Please try again.');
    return body;
  }
  function announce(message, isError) {
    var toast = document.createElement('div');
    toast.className = 'toast' + (isError ? ' error' : '');
    toast.textContent = message;
    toastRegion.appendChild(toast);
    window.setTimeout(function () { toast.remove(); }, 4300);
  }
  function updateMeta(title, description, canonical) {
    document.title = title;
    var desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute('content', description);
    var ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', title);
    var ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute('content', description);
    var link = document.querySelector('link[rel="canonical"]');
    if (link) link.setAttribute('href', window.location.origin + canonical);
  }
  function updateNav(path) {
    document.querySelectorAll('.main-nav a').forEach(function (link) {
      link.classList.toggle('active', (link.getAttribute('data-nav') === 'apps' && ['/apps', '/search'].indexOf(path) >= 0) ||
        (link.getAttribute('data-nav') === 'games' && (path === '/games' || path.indexOf('/category/') === 0)) ||
        (link.getAttribute('data-nav') === 'top-rated' && path === '/top-rated') ||
        (link.getAttribute('data-nav') === 'search' && path === '/search'));
    });
  }
  async function getApps(params) {
    var suffix = params ? '?' + new URLSearchParams(params).toString() : '';
    return api('/api/apps' + suffix);
  }
  function categoryRow() {
    return '<div class="category-row">' + config.categories.map(function (category) {
      return '<a class="category-chip" href="/category/' + esc(category.slug) + '">' + esc(category.name) + '<small>' + num(category.count) + '</small></a>';
    }).join('') + '</div>';
  }
  async function renderHome() {
    updateMeta('Betvixo — Find your next play.', config.settings.hero_description || 'Discover thoughtful mobile games and get straight to the official download.', '/');
    main.innerHTML = '<section class="hero"><div class="container hero-grid"><div class="hero-copy-wrap"><div class="eyebrow"><span class="eyebrow-mark"></span>' + esc(config.settings.announcement || 'A better kind of game discovery') + '</div>' +
      '<h1>' + heroHeading(config.settings.hero_title) + '</h1><p class="hero-copy">' + esc(config.settings.hero_description || '') + '</p>' +
      '<form class="hero-search search-form" role="search" action="/search" method="get"><span>' + searchIcon() + '</span><input name="q" type="search" placeholder="Search games, genres and more" aria-label="Search games and apps"><button class="button button-primary" type="submit">Explore <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9m-4-4 4 4-4 4"/></svg></button></form>' +
      '<div class="hero-meta"><span class="hero-meta-item"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="m8 1.5 2 4.1 4.5.7-3.3 3.2.8 4.5L8 11.9l-4 2.1.8-4.5-3.3-3.2L6 5.6z"/></svg><strong>Thoughtful picks</strong></span><span class="hero-meta-item"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5 13 3v4.1c0 3.2-2 5.5-5 7.4-3-1.9-5-4.2-5-7.4V3z"/><path d="m5.6 7.9 1.5 1.5 3.3-3.5"/></svg>Official sources</span><span class="hero-meta-item"><svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2.2" y="3" width="11.6" height="10.5" rx="2"/><path d="M5 1.8v2.5M11 1.8v2.5M2.5 6.5h11"/></svg><strong>' + num(config.total) + '</strong> finds</span></div></div>' +
      '<div id="hero-art-slot"></div></div></section>' +
      '<div class="trust-strip"><div class="container trust-inner"><span class="trust-label">The Betvixo way</span><span class="trust-item"><svg viewBox="0 0 16 16"><path d="m2 8 4 4 8-8"/></svg>Clear details</span><span class="trust-item"><svg viewBox="0 0 16 16"><path d="M8 1.5 13 3v4.1c0 3.2-2 5.5-5 7.4-3-1.9-5-4.2-5-7.4V3z"/><path d="m5.6 7.9 1.5 1.5 3.3-3.5"/></svg>Source links you can trust</span><span class="trust-item"><svg viewBox="0 0 16 16"><path d="M3 12 6.2 8.5 8.5 10l4.7-6"/><path d="M10 4h3.5v3.5"/></svg>Fresh discoveries</span><span class="trust-spacer"></span><span class="trust-note">' + esc(config.settings.home_note || '') + '</span></div></div>' +
      '<section class="section"><div class="container" id="top-rated-section">' + sectionHead('A few community favorites', 'Top rated', 'A good place to start your next session.', '/top-rated', 'See all') + '<div class="card-grid">' + [0,1,2,3].map(function () { return '<div class="skeleton skeleton-card"></div>'; }).join('') + '</div></div></section>' +
      '<section class="container"><div class="featured-panel" id="spotlight"><div class="featured-copy"><div class="eyebrow"><span class="eyebrow-mark"></span>In the spotlight</div><h2>One good find<br>changes the mood.</h2><p>Meet a hand-picked game with a little something extra. Read the details, then choose where to get it.</p><a class="button button-secondary" href="/games">Browse the collection <svg viewBox="0 0 16 16"><path d="M3 8h9m-4-4 4 4-4 4"/></svg></a></div><div class="featured-tile" aria-hidden="true"><span>✦</span></div></div></section>' +
      '<section class="section compact"><div class="container">' + sectionHead('Find your kind of fun', 'Browse by category', 'Pick a mood and see where it takes you.') + categoryRow() + '</div></section>' +
      '<section class="section compact"><div class="container" id="latest-section">' + sectionHead('Fresh off the list', 'Recently added', 'New additions to the Betvixo catalog.', '/games', 'All games') + '<div class="card-grid">' + [0,1,2,3].map(function () { return '<div class="skeleton skeleton-card"></div>'; }).join('') + '</div></div></section>';
    var topSlot = document.querySelector('#top-rated-section .card-grid');
    var latestSlot = document.querySelector('#latest-section .card-grid');
    Promise.all([getApps({ sort: 'rating', limit: '8' }), getApps({ sort: 'latest', limit: '8' })]).then(function (results) {
      if (!document.querySelector('#top-rated-section')) return;
      var topItems = results[0].items.filter(function (app) { return app.rating != null; }).slice(0, 4);
      var freshItems = results[1].items.slice(0, 4);
      topSlot.outerHTML = cardGrid(topItems);
      latestSlot.outerHTML = cardGrid(freshItems);
      var spotlight = document.getElementById('spotlight');
      var picked = results[0].items.find(function (app) { return app.featured; }) || results[0].items[0];
      if (picked && spotlight) {
        spotlight.innerHTML = '<div class="featured-copy"><div class="eyebrow"><span class="eyebrow-mark"></span>In the spotlight · ' + esc(picked.category || 'Featured') + '</div><h2>' + esc(picked.title) + '</h2><p>' + esc(picked.tagline || picked.description) + '</p><a class="button button-secondary" href="/app/' + esc(picked.slug) + '">Get to know this game <svg viewBox="0 0 16 16"><path d="M3 8h9m-4-4 4 4-4 4"/></svg></a></div><div class="featured-tile ' + 'art-' + esc(picked.icon_art || 'coral') + '" aria-hidden="true"><span>' + esc(picked.icon_mark || '✦') + '</span></div>';
      }
      var slot = document.getElementById('hero-art-slot');
      if (slot) slot.innerHTML = heroArt(picked);
    }).catch(function () {
      if (topSlot && topSlot.isConnected) topSlot.outerHTML = emptyState('Could not load the catalog', 'Refresh the page to try again.', 'Refresh', '/');
      if (latestSlot && latestSlot.isConnected) latestSlot.outerHTML = emptyState('Could not load the catalog', 'Refresh the page to try again.', 'Refresh', '/');
    });
    bindSearchForms();
  }
  function bindSearchForms() {
    document.querySelectorAll('.search-form').forEach(function (form) {
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var value = new FormData(form).get('q').toString().trim();
        navigate('/search?q=' + encodeURIComponent(value));
      });
    });
  }
  function filtersHtml(path, params, resultCount) {
    var selectedCategory = params.category || '';
    var selectedType = params.type || '';
    return '<div class="catalog-tools"><span class="result-count">' + num(resultCount) + ' ' + (resultCount === 1 ? 'result' : 'results') + '</span>' +
      '<select id="catalog-type" class="select-control" aria-label="Filter by listing type"><option value=""' + (!selectedType ? ' selected' : '') + '>All types</option><option value="game"' + (selectedType === 'game' ? ' selected' : '') + '>Games</option><option value="app"' + (selectedType === 'app' ? ' selected' : '') + '>Apps</option></select>' +
      '<select id="catalog-category" class="select-control" aria-label="Filter by category"><option value="">All categories</option>' + config.categories.map(function (item) { return '<option value="' + esc(item.slug) + '"' + (selectedCategory === item.slug ? ' selected' : '') + '>' + esc(item.name) + '</option>'; }).join('') + '</select>' +
      '<select id="catalog-sort" class="select-control" aria-label="Sort listings"><option value="latest">Recently added</option><option value="rating"' + (params.sort === 'rating' ? ' selected' : '') + '>Top rated</option><option value="popular"' + (params.sort === 'popular' ? ' selected' : '') + '>Most downloaded</option><option value="az"' + (params.sort === 'az' ? ' selected' : '') + '>A to Z</option></select></div>';
  }
  function queryCatalog(params) {
    document.getElementById('catalog-type').addEventListener('change', function (event) { params.type = event.target.value; params.page = '1'; navigate('/apps?' + new URLSearchParams(params).toString()); });
    document.getElementById('catalog-category').addEventListener('change', function (event) { params.category = event.target.value; params.page = '1'; navigate('/apps?' + new URLSearchParams(params).toString()); });
    document.getElementById('catalog-sort').addEventListener('change', function (event) { params.sort = event.target.value; params.page = '1'; navigate('/apps?' + new URLSearchParams(params).toString()); });
    var form = document.getElementById('catalog-search');
    if (form) form.addEventListener('submit', function (event) { event.preventDefault(); params.q = new FormData(form).get('q').toString().trim(); navigate('/search?q=' + encodeURIComponent(params.q)); });
    var clear = document.getElementById('clear-filters');
    if (clear) clear.addEventListener('click', function () { navigate('/apps'); });
  }
  function pagination(response, params) {
    if (response.pages <= 1) return '';
    var start = Math.max(1, response.page - 2);
    var end = Math.min(response.pages, response.page + 2);
    var links = [];
    if (response.page > 1) links.push('<a class="page-button" href="/apps?' + esc(new URLSearchParams(Object.assign({}, params, { page: String(response.page - 1) })).toString()) + '" aria-label="Previous page">←</a>');
    for (var i = start; i <= end; i++) links.push('<a class="page-button' + (i === response.page ? ' active' : '') + '" href="/apps?' + esc(new URLSearchParams(Object.assign({}, params, { page: String(i) })).toString()) + '"' + (i === response.page ? ' aria-current="page"' : '') + '>' + i + '</a>');
    if (response.page < response.pages) links.push('<a class="page-button" href="/apps?' + esc(new URLSearchParams(Object.assign({}, params, { page: String(response.page + 1) })).toString()) + '" aria-label="Next page">→</a>');
    return '<nav class="pagination" aria-label="Catalog pages">' + links.join('') + '</nav>';
  }
  async function renderCatalog(path, searchParams) {
    var params = { q: searchParams.get('q') || '', category: searchParams.get('category') || '', type: '', sort: searchParams.get('sort') || 'latest', page: searchParams.get('page') || '1' };
    var title = 'Discover games';
    var kicker = 'The Betvixo library';
    var subtitle = 'Browse the full collection and find the right fit for your next session.';
    var apiParams = { sort: params.sort };
    if (path === '/games') { title = 'Games worth a look'; kicker = 'Find your next session'; subtitle = 'A collection of mobile games to play, explore and come back to.'; params.type = 'game'; apiParams.type = 'game'; }
    if (path === '/apps') { title = 'Explore the collection'; kicker = 'Your next favorite starts here'; subtitle = 'Search the Betvixo catalog or narrow things down to what you like.'; }
    if (path === '/top-rated') { title = 'Top rated'; kicker = 'Loved by players'; subtitle = 'A look at the most highly rated picks in the catalog.'; params.sort = 'rating'; apiParams.sort = 'rating'; }
    if (path === '/search') { title = params.q ? 'Search results' : 'Search the catalog'; kicker = 'Find something good'; subtitle = params.q ? 'Results for “' + params.q + '”.' : 'Type a title, genre or keyword to get started.'; }
    if (path.indexOf('/category/') === 0) {
      params.category = path.slice('/category/'.length);
      apiParams.category = params.category;
      var category = config.categories.find(function (item) { return item.slug === params.category; });
      title = category ? category.name : 'Category'; kicker = 'Explore by category'; subtitle = category ? 'More ' + category.name.toLowerCase() + ' picks, all in one place.' : 'Browse games by category.';
    }
    if (params.q) apiParams.q = params.q;
    if (params.type) apiParams.type = params.type;
    if (params.sort) apiParams.sort = params.sort;
    apiParams.page = params.page;
    apiParams.limit = '16';
    updateMeta(title + ' — Betvixo', subtitle, path + window.location.search);
    main.innerHTML = '<div class="container catalog-layout"><div class="page-intro"><div class="breadcrumb"><a href="/">Home</a><svg viewBox="0 0 16 16"><path d="m6 3 5 5-5 5"/></svg><span>' + esc(title) + '</span></div><div class="section-kicker">' + esc(kicker) + '</div><h1>' + esc(title) + '</h1><p>' + esc(subtitle) + '</p></div>' +
      (path === '/search' ? '<form id="catalog-search" class="hero-search" role="search" style="margin:13px 0 19px;max-width:490px"><span>' + searchIcon() + '</span><input name="q" type="search" value="' + esc(params.q) + '" placeholder="Search by name or genre" aria-label="Search catalog"><button class="button button-primary" type="submit">Search</button></form>' : '') +
      filtersHtml(path, params, 0) + '<div id="catalog-results" style="margin-top:15px"><div class="card-grid">' + [0,1,2,3,4,5,6,7].map(function () { return '<div class="skeleton skeleton-card"></div>'; }).join('') + '</div></div></div>';
    var response = await getApps(apiParams).catch(function (error) { return { items: [], error: error }; });
    var results = document.getElementById('catalog-results');
    if (!results) return;
    var tools = document.querySelector('.catalog-tools');
      if (tools) tools.innerHTML = filtersHtml(path, params, response.total).replace(/^<div class="catalog-tools">|<\/div>$/g, '');
    queryCatalog(params);
      results.innerHTML = response.error ? emptyState('Catalog is unavailable', response.error.message, 'Try again', path) : cardGrid(response.items) + pagination(response, params);
  }
  function featureList(app) {
    var custom = Array.isArray(app.features) ? app.features : [];
    if (!custom.length) custom = [
      'Publisher and listing details at a glance',
      'Download source configured by the listing owner',
      'Version and file size shown when available',
      'Related picks from the same category'
    ];
    return '<div class="feature-list">' + custom.slice(0, 8).map(function (item) { return '<div class="feature-item"><span class="feature-check">✓</span><span>' + esc(item) + '</span></div>'; }).join('') + '</div>';
  }
  function ratingSummary(app) {
    if (app.rating == null) return '<div class="rating-score"><div class="rating-number">—</div><div><div class="rating-stars">Not rated</div><div class="rating-meta">No rating has been added</div></div></div>';
    return '<div class="rating-score"><div class="rating-number">' + Number(app.rating).toFixed(1) + '</div><div><div class="rating-stars" aria-label="' + Number(app.rating).toFixed(1) + ' out of 5">★★★★★</div><div class="rating-meta">' + reviews(app.review_count) + '</div></div></div>';
  }
  function gallery(app) {
    if (app.screenshots && app.screenshots.length) {
      return '<div class="gallery-grid">' + app.screenshots.map(function (shot) { return '<button class="gallery-thumb" type="button" data-lightbox="/media/' + esc(shot.file_path) + '" aria-label="View ' + esc(shot.caption || app.title) + ' screenshot"><img src="/media/' + esc(shot.file_path) + '" alt="' + esc(shot.caption || app.title + ' screenshot') + '" loading="lazy"></button>'; }).join('') + '</div>';
    }
    return '<div class="gallery-empty"><span class="gallery-empty-icon">▧</span><div><strong>Screenshots coming soon</strong><span>The listing owner can add a gallery from the Betvixo admin dashboard.</span></div></div>';
  }
  async function renderDetail(slug) {
    main.innerHTML = '<div class="container detail-page"><div class="page-intro"><div class="skeleton" style="height:19px;width:160px"></div></div><div class="card-grid">' + [0,1,2,3].map(function () { return '<div class="skeleton skeleton-card"></div>'; }).join('') + '</div></div>';
    var app;
    try { app = await api('/api/apps/' + encodeURIComponent(slug)); }
    catch (error) { main.innerHTML = '<div class="container info-page">' + emptyState('We could not find that listing', 'It may have been removed or the address has changed.', 'Back to the collection', '/apps') + '</div>'; updateMeta('Listing not found — Betvixo', error.message, '/apps'); return; }
    updateMeta(app.title + ' — Betvixo', app.tagline || app.description.slice(0, 155), '/app/' + app.slug);
    var download = app.download_available ? '<a class="button button-primary" href="/download/' + esc(app.slug) + '"><svg viewBox="0 0 16 16"><path d="M8 2v8m-3-3 3 3 3-3M3 13h10"/></svg>Download ' + (app.apk_path && !app.download_url ? 'APK' : 'from official store') + '</a>' : '<button class="button button-primary" type="button" disabled aria-disabled="true">Download link unavailable</button>';
    var invite = app.invitation_url ? '<a class="button button-secondary" href="' + esc(app.invitation_url) + '" target="_blank" rel="noopener noreferrer">Invitation / referral link <svg viewBox="0 0 16 16"><path d="M6 3H3v10h10v-3M8 2h6v6m-6 0 6-6"/></svg></a>' : '';
    var related = app.related && app.related.length ? '<div class="related-list">' + app.related.map(function (item) { return '<a class="related-item" href="/app/' + esc(item.slug) + '">' + iconMarkup(item) + '<span><strong>' + esc(item.title) + '</strong><small>' + esc(item.category || 'Game') + (item.rating ? ' · ' + Number(item.rating).toFixed(1) + ' ★' : '') + '</small></span></a>'; }).join('') + '</div>' : '<p class="detail-description">More picks will appear here as the catalog grows.</p>';
    main.innerHTML = '<div class="container detail-page"><div class="breadcrumb"><a href="/">Home</a><svg viewBox="0 0 16 16"><path d="m6 3 5 5-5 5"/></svg><a href="/games">' + esc(app.category || 'Catalog') + '</a><svg viewBox="0 0 16 16"><path d="m6 3 5 5-5 5"/></svg><span>' + esc(app.title) + '</span></div>' +
      '<div class="detail-hero"><div><div class="detail-intro">' + iconMarkup(app) + '<div class="detail-title-area"><h1>' + esc(app.title) + '</h1><p class="tagline">' + esc(app.tagline || '') + '</p><div class="detail-pills"><span class="detail-pill"><svg viewBox="0 0 16 16"><path d="m8 1.5 2 4.1 4.5.7-3.3 3.2.8 4.5L8 11.9l-4 2.1.8-4.5-3.3-3.2L6 5.6z"/></svg>' + (app.rating == null ? 'Not rated' : Number(app.rating).toFixed(1) + ' · ' + reviews(app.review_count)) + '</span><span class="detail-pill">' + esc(app.kind === 'game' ? 'Mobile game' : 'Mobile app') + '</span><span class="detail-category">' + esc(app.category || 'Uncategorised') + '</span></div></div></div>' +
      '<div class="detail-block" style="border:0;padding-bottom:0"><div class="section-kicker">About this ' + esc(app.kind) + '</div><p class="detail-description">' + esc(app.tagline || app.title) + '</p></div></div>' +
      '<div class="detail-actions">' + download + invite + '<div class="detail-actions-note"><svg viewBox="0 0 16 16"><path d="M8 1.5 13 3v4.1c0 3.2-2 5.5-5 7.4-3-1.9-5-4.2-5-7.4V3z"/><path d="m5.5 8 1.6 1.6 3.4-3.5"/></svg>Download source is shown before you continue</div></div></div>' +
      '<div class="detail-grid"><div class="detail-maincol"><section class="detail-block"><h2>About ' + esc(app.title) + '</h2><div class="detail-description">' + esc(app.description || 'More information about this listing will be added soon.') + '</div></section>' +
      '<section class="detail-block"><h2>What to know</h2>' + featureList(app) + '</section><section class="detail-block"><h2>Screenshots & gallery</h2>' + gallery(app) + '</section></div>' +
      '<aside class="detail-aside"><section class="aside-card"><h3>Ratings & reviews</h3>' + ratingSummary(app) + '<p class="rating-meta" style="margin:10px 0 0">Rating information shown for this listing.</p></section>' +
      '<section class="aside-card"><h3>App information</h3><dl class="facts-list"><div class="facts-row"><dt>Version</dt><dd>' + esc(app.version || 'Not specified') + '</dd></div><div class="facts-row"><dt>File size</dt><dd>' + esc(app.file_size || 'Not specified') + '</dd></div><div class="facts-row"><dt>Category</dt><dd>' + esc(app.category || 'Uncategorised') + '</dd></div><div class="facts-row"><dt>Updated</dt><dd>' + esc(new Date(app.updated_at).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })) + '</dd></div></dl></section>' +
      '<section class="aside-card"><h3>You may also like</h3>' + related + '</section></aside></div></div>';
  }
  function infoPage(path) {
    var pages = {
      '/about': ['About Betvixo', 'A calmer corner of the internet for finding your next mobile game.', '<p>Betvixo is an independent discovery catalog built to make browsing mobile games feel clear and straightforward. Listings bring the key details together and point you to the source configured by the listing owner.</p><h2>Made for discovery</h2><p>Search by name, explore by category, compare details and find a new favorite. Each listing is maintained through a separate admin area so the catalog can grow over time.</p><h2>Downloads</h2><p>Download links take you to an official store or to an APK uploaded by the Betvixo administrator. Check the destination and app information before installing software on your device.</p>'],
      '/privacy': ['Privacy', 'A simple explanation of how this catalog handles information.', '<p>Betvixo stores only the information needed to operate the catalog, admin account and basic download counters. Search terms are used to return matching listings and are not saved as a user profile.</p><h2>Admin access</h2><p>The admin area uses a secure session cookie and a password stored as a salted, one-way hash. Uploaded listing media and app files are stored by the site operator.</p><h2>Downloads and outside links</h2><p>When you choose a download, Betvixo counts the click and sends your browser to the configured source. That destination has its own privacy practices.</p>'],
      '/terms': ['Terms of use', 'Use the catalog thoughtfully and review sources before installing.', '<p>Betvixo provides a directory of app and game listings. Details and links are supplied by the catalog administrator and can change over time.</p><h2>External software</h2><p>Review the publisher, permissions and source before you install an app. Betvixo does not publish or modify the third-party software linked from a listing.</p><h2>Availability</h2><p>Listings and external links can be updated or removed. The site operator is responsible for maintaining the accuracy and rights for their catalog content.</p>'],
      '/contact': ['Contact Betvixo', 'Questions about the catalog? Reach out to the site owner.', config.settings.support_email ? '<p>For catalog questions, email <a href="mailto:' + esc(config.settings.support_email) + '">' + esc(config.settings.support_email) + '</a>.</p>' : '<p>A contact address has not been published yet. If you manage this site, add a support email from the admin dashboard home settings.</p>']
    };
    var page = pages[path];
    updateMeta(page[0] + ' — Betvixo', page[1], path);
    main.innerHTML = '<article class="container info-page"><div class="section-kicker">BETVIXO · THE PLAYGROUND</div><h1>' + esc(page[0]) + '</h1><p class="lead">' + esc(page[1]) + '</p>' + page[2] + '</article>';
  }
  async function render() {
    var url = new URL(window.location.href);
    var path = url.pathname.replace(/\/$/, '') || '/';
    currentPath = path;
    updateNav(path);
    document.querySelector('.main-nav').classList.remove('open');
    document.getElementById('menu-toggle').setAttribute('aria-expanded', 'false');
    if (path === '/') return renderHome();
    if (path === '/apps' || path === '/games' || path === '/top-rated' || path === '/search' || path.indexOf('/category/') === 0) return renderCatalog(path, url.searchParams);
    if (path.indexOf('/app/') === 0) return renderDetail(path.slice('/app/'.length));
    if (path === '/about' || path === '/privacy' || path === '/terms' || path === '/contact') return infoPage(path);
    main.innerHTML = '<div class="container info-page">' + emptyState('That page is not here', 'The address may have changed. Head back to the collection to keep exploring.', 'Explore games', '/games') + '</div>';
    updateMeta('Page not found — Betvixo', 'Browse the Betvixo game catalog.', '/');
  }
  function navigate(path) {
    history.pushState({}, '', path);
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
    render();
  }
  document.addEventListener('click', function (event) {
    var thumb = event.target.closest('[data-lightbox]');
    if (thumb) {
      var box = document.getElementById('lightbox');
      box.querySelector('img').src = thumb.getAttribute('data-lightbox');
      box.hidden = false;
      document.body.style.overflow = 'hidden';
      return;
    }
    var anchor = event.target.closest('a');
    if (!anchor || anchor.target === '_blank' || anchor.hasAttribute('download')) return;
    var target;
    try { target = new URL(anchor.href); } catch (_) { return; }
    if (target.origin !== window.location.origin || target.pathname.indexOf('/download/') === 0 || target.pathname.indexOf('/media/') === 0 || target.pathname.indexOf('/admin') === 0) return;
    event.preventDefault();
    navigate(target.pathname + target.search + target.hash);
  });
  document.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
  document.getElementById('lightbox').addEventListener('click', function (event) { if (event.target.id === 'lightbox') closeLightbox(); });
  function closeLightbox() { document.getElementById('lightbox').hidden = true; document.getElementById('lightbox').querySelector('img').src = ''; document.body.style.overflow = ''; }
  document.getElementById('menu-toggle').addEventListener('click', function () {
    var nav = document.querySelector('.main-nav');
    var open = nav.classList.toggle('open');
    this.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  document.querySelectorAll('.header-search').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var value = new FormData(form).get('q').toString().trim();
      navigate('/search?q=' + encodeURIComponent(value));
    });
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === '/' && !/input|textarea|select/i.test(document.activeElement.tagName)) {
      event.preventDefault();
      var input = document.querySelector('.header-search input');
      if (input) input.focus();
    }
    if (event.key === 'Escape') closeLightbox();
  });
  window.addEventListener('popstate', render);
  api('/api/config').then(function (data) { config = data; render(); }).catch(function (error) {
    main.innerHTML = '<div class="container info-page">' + emptyState('Betvixo could not connect', error.message || 'Please refresh to reconnect to the catalog.', 'Refresh', '/') + '</div>';
  });
})();
