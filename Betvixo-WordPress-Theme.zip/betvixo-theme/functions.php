<?php
if (!defined('ABSPATH')) exit;
function betvixo_theme_setup() {
  add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('custom-logo');
  add_theme_support('html5', array('search-form','gallery','caption','style','script'));
  register_nav_menus(array('primary'=>__('Primary Menu','betvixo')));
}
add_action('after_setup_theme','betvixo_theme_setup');
function betvixo_assets() { wp_enqueue_style('betvixo-theme',get_stylesheet_uri(),array(), '1.0.0'); wp_enqueue_script('betvixo-theme',get_template_directory_uri().'/assets.js',array(), '1.0.0',true); }
add_action('wp_enqueue_scripts','betvixo_assets');
function betvixo_body_classes($classes) { $classes[]='betvixo-wp'; return $classes; }
add_filter('body_class','betvixo_body_classes');
